import tensorflow as tf
import tensorflow.keras as keras
import numpy as np
import h5py

print("tensorflow:",tf.__version__)
print("keras:",keras.__version__)
print("numpy:",np.__version__)
print("h5py:",h5py.__version__)