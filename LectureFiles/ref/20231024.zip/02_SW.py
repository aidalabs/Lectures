import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

SW1 = 5
SW2 = 6
SW3 = 13
SW4 = 19

GPIO.setup(SW1, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(SW2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(SW3, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(SW4, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

old_sw = [0, 0, 0, 0]
new_sw = [0, 0, 0, 0]
counts = [0, 0, 0, 0]

sw = [SW1, SW2, SW3, SW4]

try:
    while True:
        for i in range(4):
            new_sw[i] = GPIO.input(sw[i])
            if new_sw[i] != old_sw[i]:
                old_sw[i] =new_sw[i]
                
                if new_sw[i] == 1:
                    counts[i] = counts[i] + 1
                    print('SW{} click: {}'.format(i+1, counts[i]))
                    time.sleep(0.2)
    
except KeyboardInterrupt:
    print("Keyboard Interrupt!!!")



GPIO.cleanup()