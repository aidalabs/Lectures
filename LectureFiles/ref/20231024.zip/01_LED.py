import RPi.GPIO as GPIO
import time

LED_FRONT_LEFT = 26
LED_FRONT_RIGHT = 16
LED_BACK_LEFT = 20
LED_BACK_RIGHT = 21

GPIO.setmode(GPIO.BCM)

GPIO.setup(LED_FRONT_LEFT, GPIO.OUT)
GPIO.setup(LED_FRONT_RIGHT, GPIO.OUT)
GPIO.setup(LED_BACK_LEFT, GPIO.OUT)
GPIO.setup(LED_BACK_RIGHT, GPIO.OUT)

try:
    while True:
        GPIO.output(LED_FRONT_LEFT, GPIO.HIGH)
        time.sleep(1.0)
        GPIO.output(LED_FRONT_LEFT, GPIO.LOW)
        time.sleep(1.0)

        GPIO.output(LED_FRONT_RIGHT, GPIO.HIGH)
        time.sleep(1.0)
        GPIO.output(LED_FRONT_RIGHT, GPIO.LOW)
        time.sleep(1.0)

        GPIO.output(LED_BACK_RIGHT, GPIO.HIGH)
        time.sleep(1.0)
        GPIO.output(LED_BACK_RIGHT, GPIO.LOW)
        time.sleep(1.0)

        GPIO.output(LED_BACK_LEFT, GPIO.HIGH)
        time.sleep(1.0)
        GPIO.output(LED_BACK_LEFT, GPIO.LOW)
        time.sleep(1.0)

except KeyboardInterrupt:
    print("Keyboard Interrupt!!!")
    
GPIO.cleanup()