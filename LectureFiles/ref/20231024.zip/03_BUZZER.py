import RPi.GPIO as GPIO
import time

BUZZER = 12

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(BUZZER, GPIO.OUT)

p = GPIO.PWM(BUZZER, 261)
p.start(50)

try:
    while True:
        p.start(50)
        
        p.ChangeFrequency(261)	# Do
        time.sleep(1.0)
        p.ChangeFrequency(293)	# Re
        time.sleep(1.0)
        p.ChangeFrequency(329)	# Mi
        time.sleep(1.0)
        p.ChangeFrequency(349)	# Fa
        time.sleep(1.0)
        p.ChangeFrequency(391)	# Sol
        time.sleep(1.0)
        p.ChangeFrequency(440)	# La
        time.sleep(1.0)
        p.ChangeFrequency(493)	# Si
        time.sleep(1.0)
        p.ChangeFrequency(523)	# Do
        time.sleep(1.0)
        
        p.stop()
        time.sleep(1.0)
    
except KeyboardInterrupt:
    print("Keyboard Interrupt!!")

p.stop()
GPIO.cleanup()