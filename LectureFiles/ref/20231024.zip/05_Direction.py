import RPi.GPIO as GPIO
import time

SW1 = 5
SW2 = 6
SW3 = 13
SW4 = 19

PWM_A = 18
A_IN1 = 22
A_IN2 = 27

PWM_B = 23
B_IN1 = 25
B_IN2 = 24

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(SW1, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(SW2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(SW3, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(SW4, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

GPIO.setup(PWM_A, GPIO.OUT)
GPIO.setup(A_IN1, GPIO.OUT)
GPIO.setup(A_IN2, GPIO.OUT)

GPIO.setup(PWM_B, GPIO.OUT)
GPIO.setup(B_IN1, GPIO.OUT)
GPIO.setup(B_IN2, GPIO.OUT)

left_motor = GPIO.PWM(PWM_A, 500)
left_motor.start(0)

right_motor = GPIO.PWM(PWM_B, 500)
right_motor.start(0)

try:
    while True:
        if GPIO.input(SW1) == 1:
            print('Go')
            
            GPIO.output(A_IN1, 0)
            GPIO.output(A_IN2, 1)
            left_motor.ChangeDutyCycle(50)

            GPIO.output(B_IN1, 0)
            GPIO.output(B_IN2, 1)
            right_motor.ChangeDutyCycle(50)

        elif GPIO.input(SW2) == 1:
            print('Right')
            
            GPIO.output(A_IN1, 0)
            GPIO.output(A_IN2, 1)
            left_motor.ChangeDutyCycle(50)

            GPIO.output(B_IN1, 1)
            GPIO.output(B_IN2, 0)
            right_motor.ChangeDutyCycle(50)

        elif GPIO.input(SW3) == 1:
            print('Left')
            
            GPIO.output(A_IN1, 1)
            GPIO.output(A_IN2, 0)
            left_motor.ChangeDutyCycle(50)

            GPIO.output(B_IN1, 0)
            GPIO.output(B_IN2, 1)
            right_motor.ChangeDutyCycle(50)

        elif GPIO.input(SW4) == 1:
            print('Back')
            
            GPIO.output(A_IN1, 1)
            GPIO.output(A_IN2, 0)
            left_motor.ChangeDutyCycle(50)

            GPIO.output(B_IN1, 1)
            GPIO.output(B_IN2, 0)
            right_motor.ChangeDutyCycle(50)

        else:
            print('Stop')
            GPIO.output(A_IN1, 0)
            GPIO.output(A_IN2, 1)
            left_motor.ChangeDutyCycle(0)

            GPIO.output(B_IN1, 0)
            GPIO.output(B_IN2, 1)
            right_motor.ChangeDutyCycle(0)

        time.sleep(0.1)

except KeyboardInterrupt:
    print("Keyboard Interrupt!!")

GPIO.cleanup()
