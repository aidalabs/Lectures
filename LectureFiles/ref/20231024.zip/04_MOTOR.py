import RPi.GPIO as GPIO
import time

PWM_A = 18
A_IN1 = 22
A_IN2 = 27

PWM_B = 23
B_IN1 = 25
B_IN2 = 24

GPIO.setmode(GPIO.BCM)

GPIO.setup(PWM_A, GPIO.OUT)
GPIO.setup(A_IN1, GPIO.OUT)
GPIO.setup(A_IN2, GPIO.OUT)

GPIO.setup(PWM_B, GPIO.OUT)
GPIO.setup(B_IN1, GPIO.OUT)
GPIO.setup(B_IN2, GPIO.OUT)

left_motor = GPIO.PWM(PWM_A, 500)
left_motor.start(0)

right_motor = GPIO.PWM(PWM_B, 500)
right_motor.start(0)

try:
    while True:
        GPIO.output(A_IN1, 1)
        GPIO.output(A_IN2, 0)
        left_motor.ChangeDutyCycle(50)
        
        GPIO.output(B_IN1, 1)
        GPIO.output(B_IN2, 0)
        right_motor.ChangeDutyCycle(50)
        
        time.sleep(1.0)

        GPIO.output(A_IN1, 1)
        GPIO.output(A_IN2, 0)
        left_motor.ChangeDutyCycle(0)
        
        GPIO.output(B_IN1, 1)
        GPIO.output(B_IN2, 0)
        right_motor.ChangeDutyCycle(0)
        
        time.sleep(1.0)

except KeyboardInterrupt:
    print("Keyboard Interrupt!!!")

GPIO.cleanup()