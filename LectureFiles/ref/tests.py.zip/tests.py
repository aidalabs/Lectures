from django.test import TestCase
import requests

# Create your tests here.
url = "http://127.0.0.1:8000/posts/"

header = {"Authorization": "Token " + "c5d78963bdd77939cf9e3e671245c671bf6e52c9"}
response = requests.get(url, data={"username":"seokhwan", "password":"1234asdf**"}, headers=header)
print("[Response] ", response.text)