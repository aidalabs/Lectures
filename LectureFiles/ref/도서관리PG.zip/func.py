import os

def SelectMenu():
    # os.system('cls')
    os.system("clear")

    print("도서 관리 프로그램 v0.1.0")
    print("1: 장르 추가")
    print("2: 도서 추가")
    print("3: 도서 삭제")
    print("4: 도서 검색")
    print("5: 전체 보기")
    print("0: 종료")

    return input("메뉴 선택 ☞: ")

def ViewGenres(genres):
   print("◎◎◎ 장르 목록: ({0}개)".format(len(genres)))

   for i in range(0, len(genres)):
       print("{0}: {1}".format(i+1, genres[i]), end='    ')

   print()
   print()


def ViewBook(book):
    print("{0}번 {1}도서 정보".format(book[0], book[1]))
    print("▷ 장르: {0}, 저자: {1}, 출판사: {2}, 가격: {3}".format(book[2], book[3], book[4], book[5]))
    print("================================")


def ViewBooks(books):
    print("☆☆☆ 도서 목록: ({0}개)".format(len(books)))

    for book in books:
        ViewBook(book)


def AddGenre(genres):
    print("================ 장르 추가 ================")

    ViewGenres(genres)
    genre = input("추가할 장르 명: ")
    genres.append(genre)


def Find(books, isbn):
    for i in range(0, len(books)):
        book = books[i]

        if book[0] == isbn:
            return i
        
    return -1


def AddBook(genres,books):
    print("================ 도서 추가 ================")

    ViewGenres(genres)
    gn = int(input("장르 번호: "))

    if gn <= 0 or gn > len(genres):
        print("잘못 선택하였습니다.")
        return
    
    isbn = input("ISBN: ")
    bi = Find(books, isbn)

    if bi != -1:
        print("이미 존재하는 ISBN이어서 추가할 수 없습니다.")
        return
    
    title = input("도서명: ")
    author = input("저자: ")
    publisher = input("출판사: ")
    price = input("가격: ")
    book = [isbn, title, gn, author, publisher, price]
    books.append(book)


def RemoveBook(books):
    print("================ 도서 삭제 ================")
    isbn = input("삭제할 도서의 ISBN: ")
    bi = Find(books, isbn)

    if bi == -1:
        print("존재하지 않는 ISBN입니다.")
        return
    
    book = books.pop(bi)
    ViewBook(book)
    print("삭제하였습니다.")


def FindBook(books):
    print("================ 도서 검색 ================")

    isbn = input("검색할 도서의 ISBN: ")
    bi = Find(books, isbn)

    if bi == -1:
        print("존재하지 않는 ISBN입니다.")
        return
    
    book = books[bi]
    ViewBook(book)


def ViewAll(genres, books):
    print("================ 전체 보기 ================")

    ViewGenres(genres)
    ViewBooks(books)


def Save(genres, books):
    print("---------------- 저장 ----------------")

    gfs = open("genres.csv", "w")

    for genre in genres:
        gfs.write(genre + "\n")

    gfs.close()

    bfs = open("books.csv", "w")

    for book in books:
        b_str = ""                      # 한 권의 책 정보를 하나의 문자열로 표현하기 위한 변수

        for elem in book:               # 책의 각 항목(elem)을
            b_str += str(elem) +","     # 항목을 문자열로 변환 후 ","를 더하여 b_str에 추가

        b_str = b_str[:-1] + "\n"       # 마지막 콤마를 제외한 문자열과 개행('\n')을 합산
        bfs.write(b_str)                # ISBN,제목, 장르번호,저자,출판사,가격\n" 문자열 저장

    bfs.close()


def Load(genres, books):
    print("---------------- 로딩 ----------------")

    try:
        gfs = open("genres.csv", "r")
        datas = gfs.read()
        gfs.close()
        
        ds_gs = datas.split("\n")

        for genre in ds_gs:
            if(genre == ""):
                break
            genres.append(genre)

        bfs = open("books.csv", "r")
        bs = bfs.read()
        bfs.close()
        bs_bs = bs.split("\n")

        for bstr in bs_bs:
            bes = bstr.split(",")

            if len(bes) < 6:
                break

            isbn,title = bes[0], bes[1]
            gn = int(bes[2])
            author, publisher,price = bes[3], bes[4], bes[5]
            book = [isbn, title, gn, author, publisher, price]
            books.append(book)

    except:
        print("처음 사용하시는 군요!!!")
        print("환영합니다.")
        return