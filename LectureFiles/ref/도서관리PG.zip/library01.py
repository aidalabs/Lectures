'''
도서 관리 프로그램 (리스트 사용, 클래스 사용X, 메뉴만 구현)

- 도서 관리 프로그램은 콘솔 응용 프로그램이다.
- 응용에서는 사용자와 상호작용을 담당한다.
- 응용은 사용자에게 메뉴를 보여주고 선택한 메뉴를 수행하는 것을 반복한다.
- 메뉴에는 장르 추가, 도서 추가,도서 삭제, 도서 검색, 전체 도서 보기, 프로그램 종료가 있다.
- 장르 추가를 선택하면 추가할 장르 명을 입력받아 추가한다.
- 도서 추가를 선택하면 장르를 선택하고 도서 정보를 입력받아 추가한다.
- 도서는 ISBN(주요키), 도서명, 저자, 출판사, 가격 정보를 사용자로부터 입력받는다.
- 도서 삭제 기능에서는 도서의 ISBN을 사용자로부터 입력받아 삭제한다.
- 도서 검색 기능에서는 도서의 ISBN을 사용자로부터 입력받아 검색한다.
- 전체 보기에서는 전체 도서 정보를 출력한다.

'''
import os

def SelectMenu():
    # os.system('cls')
    os.system('clear')

    print("도서 관리 프로그램 v0.1.0")
    print("1: 장르 추가")
    print("2: 도서 추가")
    print("3: 도서 삭제")
    print("4: 도서 검색")
    print("5: 전체 보기")
    print("0: 종료")

    return input("메뉴 선택 ☞: ")


def AddGenre():
    print("================ 장르 추가 ================")


def AddBook():
    print("================ 도서 추가 ================")


def RemoveBook():
    print("================ 도서 삭제 ================")


def FindBook():
    print("================ 도서 검색 ================")


def ViewAll():
    print("================ 전체 보기 ================")


def main():

    while True:
        key = SelectMenu()

        if key == "0":
            break

        elif key == "1":
            AddGenre()

        elif key == "2":
            AddBook()

        elif key == "3":
            RemoveBook()

        elif key == "4":
            FindBook()

        elif key == "5":
            ViewAll()

        else:
            print("잘못 선택하였습니다.")

        print("엔터를 누르세요.")
        input()

    print("프로그램을 종료합니다.")

if __name__ == '__main__':
    main()