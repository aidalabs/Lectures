'''
도서 관리 프로그램 (리스트 사용, 클래스 사용X, 기능 구현)

- 도서 관리 프로그램은 콘솔 응용 프로그램이다.
- 응용에서는 사용자와 상호작용을 담당한다.
- 응용은 사용자에게 메뉴를 보여주고 선택한 메뉴를 수행하는 것을 반복한다.
- 메뉴에는 장르 추가, 도서 추가,도서 삭제, 도서 검색, 전체 도서 보기, 프로그램 종료가 있다.
- 장르 추가를 선택하면 추가할 장르 명을 입력받아 추가한다.
- 도서 추가를 선택하면 장르를 선택하고 도서 정보를 입력받아 추가한다.
- 도서는 ISBN(주요키), 도서명, 저자, 출판사, 가격 정보를 사용자로부터 입력받는다.
- 도서 삭제 기능에서는 도서의 ISBN을 사용자로부터 입력받아 삭제한다.
- 도서 검색 기능에서는 도서의 ISBN을 사용자로부터 입력받아 검색한다.
- 전체 보기에서는 전체 도서 정보를 출력한다.

'''
import os

def SelectMenu():
    # os.system('cls')
    os.system("clear")

    print("도서 관리 프로그램 v0.1.0")
    print("1: 장르 추가")
    print("2: 도서 추가")
    print("3: 도서 삭제")
    print("4: 도서 검색")
    print("5: 전체 보기")
    print("0: 종료")

    return input("메뉴 선택 ☞: ")


def ViewGenres(genres):
   print("◎◎◎ 장르 목록: ({0}개)".format(len(genres)))
   
   for i in range(0, len(genres)):
       print("{0}: {1}".format(i+1, genres[i]), end='    ')
   
   print()
   print()


def ViewBook(book):
    print("{0}번 {1} 도서 정보".format(book[0], book[1]))
    print("▷ 장르: {0}, 저자: {1}, 출판사: {2}, 가격: {3}".format(book[2], book[3], book[4], book[5]))
    print("================================")


def ViewBooks(books):
    print("☆☆☆ 도서 목록: ({0}개)".format(len(books)))
    
    for book in books:
        ViewBook(book)


def AddGenre(genres):
    print("================ 장르 추가 ================")

    ViewGenres(genres)
    genre = input("추가할 장르 명: ")
    genres.append(genre)


def Find(books, isbn):
    for i in range(0, len(books)):
        book = books[i]

        if book[0] == isbn:
            return i
        
    return -1


def AddBook(genres, books):
    print("================ 도서 추가 ================")

    ViewGenres(genres)
    gn = int(input("장르 번호: "))

    if gn <= 0 or gn > len(genres):
        print("잘못 선택하였습니다.")
        return
    
    isbn = input("ISBN: ")
    bi = Find(books, isbn)

    if bi != -1:
        print("이미 존재하는 ISBN이어서 추가할 수 없습니다.")
        return
    
    title = input("도서명: ")
    author = input("저자: ")
    publisher = input("출판사: ")
    price = input("가격: ")
    book = [isbn, title, gn, author, publisher, price]
    books.append(book)


def RemoveBook(books):
    print("================ 도서 삭제 ================")

    isbn = input("삭제할 도서의 ISBN: ")
    bi = Find(books, isbn)

    if bi == -1:
        print("존재하지 않는 ISBN입니다.")
        return
    
    book = books.pop(bi)
    ViewBook(book)
    print("삭제하였습니다.")


def FindBook(books):
    print("================ 도서 검색 ================")

    isbn = input("검색할 도서의 ISBN: ")
    bi = Find(books, isbn)

    if bi == -1:
        print("존재하지 않는 ISBN입니다.")
        return
    
    book = books[bi]
    ViewBook(book)


def ViewAll(genres, books):
    print("================ 전체 보기 ================")
    ViewGenres(genres)
    ViewBooks(books)


def main():
    genres = list()
    books = list()

    while True:
        key = SelectMenu()

        if key == '0':
            break

        elif key == '1':
            AddGenre(genres)

        elif key == '2':
            AddBook(genres, books)

        elif key == '3':
            RemoveBook(books)

        elif key == '4':
            FindBook(books)

        elif key == '5':
            ViewAll(genres, books)

        else:
            print("잘못 선택하였습니다.")

        print("엔터를 누르세요.")
        input()

    print("프로그램을 종료합니다.")


if __name__ == '__main__':
    main()