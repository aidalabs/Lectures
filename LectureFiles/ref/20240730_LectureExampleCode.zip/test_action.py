def test_smoke_test():
    assert 1 == 1, "반드시 같아야죠~"