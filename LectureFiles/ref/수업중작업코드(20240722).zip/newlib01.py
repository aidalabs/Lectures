import os
import time

def selectMenu():
    os.system("clear")

    print("#########################################")
    print("  도서관 출납 관리 프로그램 ver. 0.1.0")
    print("#########################################")
    print()
    print("1: 카테고리 추가")
    print("2: 도서 추가")
    print("3: 도서 삭제")
    print("4: 도서 검색")
    print("5: 전체 보기")
    print("0: 종료")
    print()
    return input("메뉴 선택: ")


def viewCategoryList(lsCategory):
    print("[등록된 카테고리: {}개]".format(len(lsCategory)))
    for i, category in enumerate(lsCategory):
        print("{}: {}".format(i+1, category), end="    ")


def addCategory(lsCategory):
    print("----------------- 카테고리 추가 -----------------")
    viewCategoryList(lsCategory)
    category_name = input("\n카테고리 명: ")
    lsCategory.append(category_name)


def addBook(lsCategory, lsBook):
    print("----------------- 도서 추가 -----------------")
    viewCategoryList(lsCategory)
    category_code = input("\n카테고리 번호: ")
    category_code = int(category_code) - 1

    if category_code < 0 or category_code > len(lsCategory) - 1:
        print("잘못 선택하셨습니다.")
        return
    
    isbn = input("ISBN: ")
    title = input("도서명: ")
    author = input("저자: ")
    publisher = input("출판사: ")
    price = input("가격: ")

    book = [category_code, isbn, title, author, publisher, price]
    lsBook.append(book)


def delBook(lsCategory, lsBook):
    print("----------------- 도서 삭제 -----------------")
    isbn = input("삭제할 도서의 ISBN: ")
    found_isbn = findISBN(lsBook, isbn)

    if found_isbn == -1:
        print("존재하지 않는 ISBN입니다.")
        return
    
    book = lsBook.pop(found_isbn)
    print("삭제된 도서: [{}] {} -{}({}, ISBN:{}) {}원".format(lsCategory[book[0]], book[2], book[3], book[4], book[1], book[5]))

    
def findISBN(lsBook, isbn):
    for i in range(0, len(lsBook)):
        book = lsBook[i]

        if book[1] == isbn:
            return i
        
    return -1


def searchBook(lsCategory, lsBook):
    print("----------------- 도서 검색 -----------------")
    isbn = input("검색할 도서의 ISBN: ")
    found_isbn = findISBN(lsBook, isbn)
    book = lsBook[found_isbn]
    print("[{}] {} -{}({}, ISBN:{}) {}원".format(lsCategory[book[0]], book[2], book[3], book[4], book[1], book[5]))


def viewBookList(lsCategory, lsBook):
    print("----------------- 전체 보기 -----------------")
    print("[등록된 도서: {}개]".format(len(lsBook)))
    for i, book in enumerate(lsBook):
        print("{}. [{}] {} -{}({}, ISBN:{}) {}원".format(i+1, lsCategory[book[0]], book[2], book[3], book[4], book[1], book[5]))


def main():
    lsCategory = list()
    lsBook = list()

    while True:
        menu = selectMenu()

        if menu == "0":
            break
        elif menu == "1":
            addCategory(lsCategory)
        elif menu == "2":
            addBook(lsCategory, lsBook)
        elif menu == "3":
            delBook(lsCategory, lsBook)
        elif menu == "4":
            searchBook(lsCategory, lsBook)
        elif menu == "5":
            viewBookList(lsCategory, lsBook)
        else:
            print("메뉴 선택을 잘못했습니다.")

        # time.sleep(3)
        input("아무 키나 눌러주세요...")

    print("프로그램을 종료합니다.")


if __name__ == "__main__":
    main()