class Book:
    def __init__(self, category, title, author, isbn, publisher, price):
        self.category = category
        self.title = title
        self.author = author
        self.isbn = isbn
        self.publisher = publisher
        self.price = price

    def write(self, fs):
        fs.write(str(self.category) + ",")
        fs.write(self.title + ",")
        fs.write(self.author + ",")
        fs.write(self.isbn +",")
        fs.write(self.publisher + ",")
        fs.write(str(self.price) + "\n")

    @staticmethod
    def load(fs):
        data = fs.readline()
        elems = data.split(',')

        if len(elems) < 6:
            return None
        
        category = int(elems[0])
        title = elems[1]
        author = elems[2]
        isbn = elems[3]
        publisher = elems[4]
        price = elems[5]

        return Book(category, title, author, isbn, publisher, price)