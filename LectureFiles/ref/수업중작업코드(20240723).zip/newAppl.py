import os
from newBook import Book

class Application:
    def __init__(self):
        self.lsCategory = list()
        self.lsBook = list()

    def Run(self):
        self.loadData()

        while True:
            menu = self.selectMenu()

            if menu == "0":
                self.saveData()
                input("프로그램을 종료합니다.")
                break
            elif menu == "1":
                self.addCategory()
            elif menu == "2":
                self.addBook()
            elif menu == "3":
                self.delBook()
            elif menu == "4":
                self.searchBook()
            elif menu == "5":
                self.viewBookList()
            else:
                print("메뉴 선택을 잘못했습니다.")
                
            input("아무 키나 눌러주세요...")


    def loadData(self):
        self.loadCategory()
        self.loadBooks()

    def loadCategory(self):
        fs = open("category.csv", "r")
        data = fs.read()
        self.lsCategory = data.split("\n")
        fs.close()
        self.lsCategory.pop()

    def loadBooks(self):
        fs = open('books.csv', "r")

        while True:
            book = Book.load(fs)
            if book == None:
                break
            self.lsBook.append(book)

        fs.close()


    def saveData(self):
        self.saveCategory()
        self.saveBooks()

    def saveCategory(self):
        fs = open("category.csv", "w")

        for category in self.lsCategory:
            if category != "":
                fs.write(category + "\n")

        fs.close()


    def saveBooks(self):
        fs = open("books.csv", "w")
        for book in self.lsBook:
            book.write(fs)

        fs.close()


    def selectMenu(self):
        os.system("clear")

        print("#########################################")
        print("  도서관 출납 관리 프로그램 ver. 0.1.0")
        print("#########################################")
        print()
        print("1: 카테고리 추가")
        print("2: 도서 추가")
        print("3: 도서 삭제")
        print("4: 도서 검색")
        print("5: 전체 보기")
        print("0: 종료")
        print()
        return input("메뉴 선택: ")


    def viewCategoryList(self):
        print("[등록된 카테고리: {}개]".format(len(self.lsCategory)))
        for i, category in enumerate(self.lsCategory):
            print("{}: {}".format(i+1, category), end="    ")


    def addCategory(self):
        print("----------------- 카테고리 추가 -----------------")
        self.viewCategoryList()
        category_name = input("\n카테고리 명: ")
        if category_name != "":
            self.lsCategory.append(category_name)


    def addBook(self):
        print("----------------- 도서 추가 -----------------")
        self.viewCategoryList()
        category_code = input("\n카테고리 번호: ")
        category_code = int(category_code) - 1

        if category_code < 0 or category_code > len(self.lsCategory) - 1:
            print("잘못 선택하셨습니다.")
            return
        
        isbn = input("ISBN: ")
        check_isbn = self.findISBN(isbn)
        if check_isbn != -1:
            print("이미 존재하는 ISBN입니다.")
            return

        title = input("도서명: ")
        author = input("저자: ")
        publisher = input("출판사: ")
        price = input("가격: ")

        book = Book(category_code, title, author, isbn, publisher, price)
        self.lsBook.append(book)


    def delBook(self):
        print("----------------- 도서 삭제 -----------------")
        isbn = input("삭제할 도서의 ISBN: ")
        found_isbn = self.findISBN(isbn)

        if found_isbn == -1:
            print("존재하지 않는 ISBN입니다.")
            return
        
        book = self.lsBook.pop(found_isbn)
        print("삭제된 도서: [{}] {} -{}({}, ISBN:{}) {}원".format(self.lsCategory[book.category], book.title, book.author, book.publisher, book.isbn, book.price))

        
    def findISBN(self, isbn):
        for i in range(0, len(self.lsBook)):
            book = self.lsBook[i]

            if book.isbn == isbn:
                return i
            
        return -1


    def searchBook(self):
        print("----------------- 도서 검색 -----------------")
        isbn = input("검색할 도서의 ISBN: ")
        found_isbn = self.findISBN(isbn)
        book = self.lsBook[found_isbn]
        print("[{}] {} -{}({}, ISBN:{}) {}원".format(self.lsCategory[book.category], book.title, book.author, book.publisher, book.isbn, book.price))


    def viewBookList(self):
        print("----------------- 전체 보기 -----------------")
        print("[등록된 도서: {}개]".format(len(self.lsBook)))
        for i, book in enumerate(self.lsBook):
            print("{}. [{}] {} -{}({}, ISBN:{}) {}원".format(i+1, self.lsCategory[book.category], book.title, book.author, book.publisher, book.isbn, book.price))

