class Library:
    def __init__(self, name, lsBook):
        self.name = name
        self.lsBook = lsBook

    def addBook(self, book):
        if book.title not in self.lsBook:
            self.lsBook.append(book)
            book.location = self.name
        else:
            print("이미 존재하는 도서입니다.")

    def removeBook(self, book):
        if self.checkBookExist(book):
            self.lsBook.remove(book)
            book.location = None
        else:
            print("해당 도서는 존재하지 않습니다.")

    def checkBookExist(self, book):
        book_list = []
        for bk in self.lsBook:
            book_list.append(bk.title)

        if book.title in book_list:
            return True

        return False
    
    @property
    def info(self):
        return f"현재 {self.name}에서 보유하고 있는 도서는 다음과 같습니다.\n{self.lsBook}"

class Book:
    def __init__(self, title):
        self.title = title
        self.location = None

    def __repr__(self):
        return f"{self.title}"

    @property
    def isBorrowed(self):
        return f"현재 해당 도서의 위치: {self.location}"

class User:
    def __init__(self, username, user_book_list):
        self.userName = username
        self.userBookList = user_book_list

    def borrowBook(self, library, book):
        if not self.checkBookExist(book):
            self.userBookList.append(book)
            library.removeBook(book)
            book.location = self.userName
        else:
            print("해당 도서는 존재하지 않습니다.")

    def checkBookExist(self, book):
        book_list = []
        for bk in self.userBookList:
            book_list.append(bk.title)

        if book.title in book_list:
            return True

        return False
    
    def returnBook(self, library, book):
        if book in self.userBookList:
            library.lsBook.append(book)
            self.userBookList.remove(book)
            book.location = library.name
        else:
            print("해당 도서를 소지하고 있지 않습니다.")

seoul = Library('Seoul Library', [])

harry_potter = Book("Harry Potter")
load_of_ring = Book("The Lord of the Ring")
marvel_comics = Book("Marvel Comics")
sherlock = Book("Sherlock Holmes")
flow = Book("Flow")

seoul.addBook(harry_potter)
seoul.addBook(load_of_ring)
seoul.addBook(marvel_comics)
seoul.addBook(sherlock)
seoul.addBook(flow)

print("-------------------------------")
print(seoul.info)
print("-------------------------------")

seoul.removeBook(flow)
print(seoul.info)
print("-------------------------------")

user = User("박찬혁", [])

user.borrowBook(seoul, harry_potter)
user.borrowBook(seoul, sherlock)
print(seoul.info)
print(f"{user.userName}이 가지고 있는 도서는 {user.userBookList}입니다.")

print("-------------------------------")
user.returnBook(seoul, harry_potter)
print(seoul.info)
print(user.userBookList)

print("-------------------------------")
print(f"도서 'sherlock'의 현재 위치는 '{sherlock.isBorrowed}'입니다.")
