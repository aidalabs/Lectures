from newAppl import Application

def main():
    app = Application()
    app.Run()

if __name__ == "__main__":
    main()