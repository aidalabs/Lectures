from django.contrib import admin
from photolist.models import Photo

# Register your models here.
admin.site.register(Photo)